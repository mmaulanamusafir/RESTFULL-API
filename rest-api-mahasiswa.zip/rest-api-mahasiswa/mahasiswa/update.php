<?php
include '../config/database.php';

$data = json_decode(file_get_contents("php://input"));

$id = $data->id;
$nama = $data->nama;
$prodi = $data->prodi;

$sql = "UPDATE mahasiswa
        SET nama='$nama',
            prodi='$prodi'
        WHERE id='$id'";

if(mysqli_query($conn,$sql)){
    echo json_encode([
        "message"=>"Data berhasil diupdate"
    ]);
}
?>